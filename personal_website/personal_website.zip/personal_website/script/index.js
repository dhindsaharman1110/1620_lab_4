


function createCourseArray(){

    let course_desc11 = document.querySelector('body > main > ol > li:nth-child(2) > section > a').outerHTML
    let course_desc12 = document.querySelector('body > main > ol > li:nth-child(2) > section > p').outerHTML


    let course_desc21 = document.querySelector('body > main > ol > li:nth-child(4) > section > a').outerHTML
    let course_desc22 = document.querySelector('body > main > ol > li:nth-child(4) > section > p.heading').outerHTML


    let course_desc31 = document.querySelector('body > main > ol > li:nth-child(6) > section > a').outerHTML
    let course_desc32 = document.querySelector('body > main > ol > li:nth-child(6) > section > p').outerHTML

    let course_array1={code: course_desc11,
                        name: course_desc12                    
    }


    let course_array2={code: course_desc21,
        name: course_desc22                    
    }


    let course_array3={code: course_desc31,
        name: course_desc32                    
    }


    let course_array={course_array1, course_array2, course_array3}

    return course_array

}




function findCourse(courseList){
    input_number=prompt('Enter your course number (4-digit)')


    while (input_number.length !=4  || isNaN(input_number)==true){
        input_number=prompt('Enter valid 4-digit course number')
    }


    for (let i=0; i< Object.keys(courseList).length; i++){
        if( Object.keys(courseList[i].code.includes(input_number) == true)){
            let f= courseList[i].code
            f.style.background = "lightgreen"
        }
        
    }


}




course_fin_array=createCourseArray();
findCourse(course_fin_array)















